import { Component, OnInit } from '@angular/core';

class Dia {
  nombre: string;
  puntos: number;
}

@Component({
  selector: 'app-dia',
  templateUrl: './dia.component.html',
  styleUrls: ['./dia.component.css']
})
export class DiaComponent implements OnInit {

  lineas: any[] = [{'nombre' : 'fulereno', 'puntos' : 3 }];

  constructor() {
    
  }

  ngOnInit() {
  }

  clicou(nombre, puntos) {
    console.log('nom: ' + nombre + ' pun: ' + puntos);
    this.lineas.push({'nombre' : nombre, 'puntos' : puntos});
  }

}
